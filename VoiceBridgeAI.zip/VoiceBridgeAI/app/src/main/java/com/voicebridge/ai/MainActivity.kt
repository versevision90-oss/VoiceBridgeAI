package com.voicebridge.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var spinFrom: Spinner
    private lateinit var spinTo: Spinner
    private lateinit var tvStatus: TextView
    private lateinit var tvOriginal: TextView
    private lateinit var tvTranslated: TextView
    private lateinit var btnMic: FloatingActionButton
    private lateinit var btnSpeak: MaterialButton
    private lateinit var btnSwap: MaterialButton

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var listening = false
    private var tagIndex = 0
    private var lastTranslated = ""

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                tagIndex = 0
                startListening()
            } else {
                setStatus(getString(R.string.mic_denied))
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinFrom = findViewById(R.id.spinFrom)
        spinTo = findViewById(R.id.spinTo)
        tvStatus = findViewById(R.id.tvStatus)
        tvOriginal = findViewById(R.id.tvOriginal)
        tvTranslated = findViewById(R.id.tvTranslated)
        btnMic = findViewById(R.id.btnMic)
        btnSpeak = findViewById(R.id.btnSpeak)
        btnSwap = findViewById(R.id.btnSwap)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            Languages.all.map { it.label }
        )
        spinFrom.adapter = adapter
        spinTo.adapter = adapter
        spinFrom.setSelection(0) // Pashto
        spinTo.setSelection(1)   // English

        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
        }

        btnSwap.setOnClickListener {
            val a = spinFrom.selectedItemPosition
            spinFrom.setSelection(spinTo.selectedItemPosition)
            spinTo.setSelection(a)
        }

        btnMic.setOnClickListener {
            if (listening) {
                stopListening()
            } else if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                tagIndex = 0
                startListening()
            } else {
                micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }

        btnSpeak.setOnClickListener {
            if (lastTranslated.isNotBlank()) speak(lastTranslated)
        }

        setStatus(getString(R.string.status_ready))
    }

    private fun fromLang() = Languages.all[spinFrom.selectedItemPosition]
    private fun toLang() = Languages.all[spinTo.selectedItemPosition]

    private fun setStatus(msg: String) {
        tvStatus.text = msg
    }

    private fun updateMic() {
        btnMic.setImageResource(if (listening) R.drawable.ic_stop else R.drawable.ic_mic)
        btnMic.contentDescription =
            getString(if (listening) R.string.stop_recording else R.string.start_recording)
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    // ---------- Speech to text ----------

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus(getString(R.string.no_recognizer))
            return
        }
        val from = fromLang()
        val tag = from.speechTags[tagIndex.coerceAtMost(from.speechTags.size - 1)]

        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(listener)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

        tvOriginal.text = ""
        tvTranslated.text = ""
        lastTranslated = ""
        listening = true
        updateMic()
        setStatus(getString(R.string.status_listening, from.name))
        r.startListening(intent)
    }

    private fun stopListening() {
        recognizer?.stopListening()
        setStatus(getString(R.string.status_processing))
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!t.isNullOrBlank()) tvOriginal.text = t
        }

        override fun onResults(results: Bundle?) {
            listening = false
            updateMic()
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (text.isNullOrBlank()) {
                setStatus(getString(R.string.err_no_match))
            } else {
                tvOriginal.text = text
                translateNow(text)
            }
        }

        override fun onError(error: Int) {
            listening = false
            updateMic()
            // 12 = language not supported, 13 = language unavailable: try next locale
            if ((error == 12 || error == 13) && tagIndex + 1 < fromLang().speechTags.size) {
                tagIndex++
                startListening()
                return
            }
            val msg = when (error) {
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> getString(R.string.no_internet)
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> getString(R.string.err_no_match)
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> getString(R.string.mic_denied)
                12, 13 -> getString(R.string.err_lang_unsupported, fromLang().name)
                else -> getString(R.string.err_generic)
            }
            setStatus(msg)
        }
    }

    // ---------- Translation ----------

    private fun translateNow(text: String) {
        setStatus(getString(R.string.status_translating))
        TranslationService.translate(text, fromLang(), toLang()) { result ->
            result.onSuccess { out ->
                lastTranslated = out
                tvTranslated.text = out
                setStatus(getString(R.string.status_done))
                speak(out)
            }.onFailure {
                setStatus(
                    if (!isOnline()) getString(R.string.no_internet)
                    else getString(R.string.err_translate)
                )
            }
        }
    }

    // ---------- Text to speech ----------

    private fun speak(text: String) {
        if (!ttsReady) {
            setStatus(getString(R.string.err_tts_not_ready))
            return
        }
        val lang = toLang()
        var ok = false
        for (tag in lang.ttsTags) {
            val res = tts?.setLanguage(Locale.forLanguageTag(tag))
                ?: TextToSpeech.LANG_NOT_SUPPORTED
            if (res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED) {
                ok = true
                break
            }
        }
        if (!ok) {
            setStatus(getString(R.string.err_no_voice, lang.name))
            return
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "voicebridge")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
