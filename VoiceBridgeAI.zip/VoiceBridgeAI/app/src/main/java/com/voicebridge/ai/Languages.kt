package com.voicebridge.ai

/**
 * code      : language code used for translation
 * speechTags: locales tried (in order) for speech recognition
 * ttsTags   : locales tried (in order) for spoken output
 * mlKit     : true if Google ML Kit can translate it on-device (Pashto is not supported)
 */
data class Lang(
    val code: String,
    val label: String,
    val name: String,
    val speechTags: List<String>,
    val ttsTags: List<String>,
    val mlKit: Boolean
)

object Languages {
    val all = listOf(
        Lang("ps", "Pashto (پښتو)", "Pashto", listOf("ps-AF"), listOf("ps-AF", "ps"), false),
        Lang("en", "English", "English", listOf("en-US"), listOf("en-US"), true),
        Lang("fa", "Dari (دری)", "Dari", listOf("fa-AF", "fa-IR"), listOf("fa-AF", "fa-IR"), true),
        Lang("ur", "Urdu (اردو)", "Urdu", listOf("ur-PK", "ur-IN"), listOf("ur-PK", "ur-IN"), true),
        Lang("ar", "Arabic (العربية)", "Arabic", listOf("ar-SA"), listOf("ar-SA", "ar"), true)
    )
}
