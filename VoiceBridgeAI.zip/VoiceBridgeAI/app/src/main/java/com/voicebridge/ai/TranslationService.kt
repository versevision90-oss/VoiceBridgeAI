package com.voicebridge.ai

import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.Html
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * Free translation, no API key:
 * 1) Google ML Kit (on-device) for English, Arabic, Urdu, Persian/Dari.
 * 2) MyMemory free web API for anything involving Pashto (or if ML Kit fails).
 * Callbacks are always delivered on the main thread.
 */
object TranslationService {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun translate(text: String, from: Lang, to: Lang, callback: (Result<String>) -> Unit) {
        if (from.code == to.code) {
            callback(Result.success(text))
            return
        }
        if (from.mlKit && to.mlKit) {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(from.code)
                .setTargetLanguage(to.code)
                .build()
            val client = Translation.getClient(options)
            client.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnSuccessListener {
                    client.translate(text)
                        .addOnSuccessListener { out ->
                            client.close()
                            callback(Result.success(out))
                        }
                        .addOnFailureListener {
                            client.close()
                            online(text, from, to, callback)
                        }
                }
                .addOnFailureListener {
                    client.close()
                    online(text, from, to, callback)
                }
        } else {
            online(text, from, to, callback)
        }
    }

    private fun online(text: String, from: Lang, to: Lang, callback: (Result<String>) -> Unit) {
        executor.execute {
            val result = runCatching {
                val q = URLEncoder.encode(text.take(450), "UTF-8")
                val url = URL(
                    "https://api.mymemory.translated.net/get?q=$q&langpair=${from.code}%7C${to.code}"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 15000
                try {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(body)
                    if (json.optInt("responseStatus", 200) != 200) {
                        error("Translation service returned an error")
                    }
                    val raw = json.getJSONObject("responseData").getString("translatedText")
                    if (Build.VERSION.SDK_INT >= 24) {
                        Html.fromHtml(raw, Html.FROM_HTML_MODE_LEGACY).toString()
                    } else {
                        raw
                    }
                } finally {
                    conn.disconnect()
                }
            }
            main.post { callback(result) }
        }
    }
}
